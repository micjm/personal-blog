# House trades: mean-return reconstruction

This accompanies the draft at `content/blog/house-trades-mean-returns.md`.
It reconstructs [Arkanum's House-trade study](https://arkanumdata.com/research/house-trades), then replaces cross-sectional medians with arithmetic means. Original analysis code was not available.

## Run

Python 3.9+ with the packages in `requirements.txt`. A prepared environment is `/tmp/house-returns-venv/bin/python`. From the repository root:

```sh
python analysis/house-trades-mean/fetch_prices.py
python analysis/house-trades-mean/analyze.py
python analysis/house-trades-mean/summarize.py
python analysis/house-trades-mean/charts.py
```

`fetch_prices.py` only checks the frozen cache. It does not download tickers or write into the cache.

Read-only inputs live at `/Users/michaelmayer/personal-blog/analysis/house-trades-mean/.cache/` (or `$HOUSE_TRADES_CACHE`). Override with that environment variable if needed. Derived trade-level files go to `analysis/house-trades-mean/.derived/` and are not published. Aggregate results are in `static/data/house-trades-mean/`. Raw filings and price histories are not in the ZIP.

## Sources

- [Original methods](https://arkanumdata.com/research/house-trades)
- [Original results and appendix](https://arkanumdata.com/research/house-trades/results)
- [Arkanum methodology](https://arkanumdata.com/research/methodology)
- [Arkanum open-data documentation](https://arkanumdata.com/open-data)
- [House-trade JSON](https://arkanumdata.com/data/congress-trades.json)
- Yahoo Finance chart endpoint, split/dividend-adjusted daily closes, through 2026-11-13.
- Source update: 2026-11-14T00:14:25.290Z. Retrieved 2026-11-15.

Credit: Arkanum Data for collecting and labeling House Clerk disclosures. Independent research using their public research download. Do not redistribute its raw files or market price histories with the blog.

## Sample and returns

See `AUDIT.md` for validation, exclusion labels, and discrepancies versus the published table. Rules used here:

1. Drop four `du` rows with unclear transaction dates. Deduplicate on member, ticker, trade date, filing date, direction, amount bounds, owner, and source URL. Keep separately reported owners, dates, amounts, or filings.
2. Map share-class punctuation only as stored in the cache (`BRK.B.json`). Do not infer ticker aliases.
3. Member entry is the first SPY session on or after the transaction date. Follower entry is the first SPY session strictly after the disclosure date.
4. Exit 21, 63, or 126 SPY sessions later. Require positive adjusted closes for the stock and benchmark on those exact sessions. Incomplete horizons are dropped, not shortened.
5. Stock return is `100 * (adjusted_close_exit / adjusted_close_entry - 1)`. Excess is that minus SPY or RSP over the same sessions.
6. Equal-weight arithmetic mean of excess returns is the headline statistic. Medians and the share above zero are reported for comparison. No annualizing, compounding across trades, winsorizing, or trimming.
7. Amount-weighted means use `(lo + hi) / 2` as encoded in the source. Endpoints can include source-assigned caps; they are not exact dollar sizes.
8. Sales report the subsequent return of the stock sold. They are not negated or treated as shorts.
9. Disclosure-delay returns run from the member-entry close to the follower-entry close, relative to SPY.

The ten most active traders are ranked on all retained purchases plus sales. Group filters match the original appendix: party, reported size, ownership (`Self` vs other), disclosure lag, and activity. Unknown parties remain in All and other applicable groups.

## Uncertainty

Resample whole disclosure months with replacement, 400 draws, seed 20261115, and report the 5th and 95th percentiles of the mean. Buy-minus-sale contrasts use a shared month universe. Tail contributions take `ceil(n * 0.05)` rows and divide each subset's sum by n.

These are overlapping fixed-window event returns, not portfolio returns.
