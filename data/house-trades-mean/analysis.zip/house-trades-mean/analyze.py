"""Reconstruct House-trade event-window returns from the frozen cache.

Reads Arkanum's congress-trades snapshot and Yahoo adjusted closes. Writes
trade-level derived columns locally. Does not download, mutate the frozen
cache, or republish raw filings or prices.

Returns are simple close-to-close total returns in percentage points:
    100 * (adj_close_exit / adj_close_entry - 1)
Excess return is that quantity minus the matched SPY or RSP return over the
same sessions. Sales are the subsequent performance of the stock sold, not
short profits. These are overlapping event windows, not portfolio returns.
"""
from __future__ import annotations

import bisect
import collections
import datetime as dt
import json
import os
import pathlib

import numpy as np
import pandas as pd

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parents[1]
FROZEN_CACHE = pathlib.Path(
    "/Users/michaelmayer/personal-blog/analysis/house-trades-mean/.cache"
)
DERIVED = HERE / ".derived"
HORIZONS = (21, 63, 126)
BENCHMARKS = ("SPY", "RSP")
SEED = 20261115
DEDUPE_KEYS = ("m", "t", "d", "f", "y", "lo", "hi", "o", "u")
META_STEMS = {
    "congress-trades",
    "sample",
    "excluded",
    "excluded-next",
    "excluded-same",
}


def cache_dir() -> pathlib.Path:
    env = os.environ.get("HOUSE_TRADES_CACHE")
    if env:
        path = pathlib.Path(env)
        if not (path / "congress-trades.json").is_file():
            raise FileNotFoundError(f"HOUSE_TRADES_CACHE has no congress-trades.json: {path}")
        return path
    if (FROZEN_CACHE / "congress-trades.json").is_file():
        return FROZEN_CACHE
    local = HERE / ".cache"
    if (local / "congress-trades.json").is_file():
        return local
    raise FileNotFoundError(
        "Frozen cache not found. Expected congress-trades.json under "
        f"{FROZEN_CACHE} or analysis/house-trades-mean/.cache/"
    )


OUT = HERE
CACHE = cache_dir()


def session_date(timestamp: int) -> str:
    """Yahoo daily bars are session-open unix times. UTC calendar date matches NY."""
    return dt.datetime.fromtimestamp(int(timestamp), dt.timezone.utc).strftime("%Y-%m-%d")


def load_series(path: pathlib.Path) -> dict | None:
    """Parse one Yahoo chart JSON into dates, positive adj closes, and firstTradeDate."""
    try:
        obj = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    chart = obj.get("chart") or {}
    result = chart.get("result")
    if chart.get("error") or not result:
        meta_first = None
        if result:
            first = result[0].get("meta", {}).get("firstTradeDate")
            meta_first = session_date(first) if first else None
        return {
            "dates": [],
            "values": np.array([]),
            "index": {},
            "first": meta_first,
            "symbol": None,
            "empty": True,
        }
    payload = result[0]
    first_raw = payload.get("meta", {}).get("firstTradeDate")
    timestamps = payload.get("timestamp") or []
    adj = (
        (payload.get("indicators") or {})
        .get("adjclose", [{}])[0]
        .get("adjclose")
        or []
    )
    dates = []
    values = []
    for ts, value in zip(timestamps, adj):
        if value is None or value <= 0:
            continue
        dates.append(session_date(ts))
        values.append(float(value))
    if not dates:
        return {
            "dates": [],
            "values": np.array([]),
            "index": {},
            "first": session_date(first_raw) if first_raw else None,
            "symbol": payload.get("meta", {}).get("symbol"),
            "empty": True,
        }
    arr = np.array(values, dtype=float)
    return {
        "dates": dates,
        "values": arr,
        "index": {day: i for i, day in enumerate(dates)},
        "first": session_date(first_raw) if first_raw else None,
        "symbol": payload.get("meta", {}).get("symbol"),
        "empty": False,
    }


def candidate_trades(raw_rows: list) -> tuple[list, dict]:
    """Drop unclear dates and identical filing lines. Keep last copy of a duplicate."""
    unclear = [row for row in raw_rows if row.get("du")]
    seen = {}
    extra_duplicates = 0
    for row in raw_rows:
        if row.get("du"):
            continue
        key = tuple(row.get(k) for k in DEDUPE_KEYS)
        if key in seen:
            extra_duplicates += 1
        seen[key] = row
    stats = {
        "raw_rows": len(raw_rows),
        "unclear_dates_removed": len(unclear),
        "duplicate_groups": sum(1 for n in collections.Counter(
            tuple(row.get(k) for k in DEDUPE_KEYS) for row in raw_rows if not row.get("du")
        ).values() if n > 1),
        "duplicate_rows_removed": extra_duplicates,
        "candidate_rows": len(seen),
    }
    return list(seen.values()), stats


def entry_on_or_after(calendar: list[str], day: str) -> int | None:
    i = bisect.bisect_left(calendar, day)
    return i if i < len(calendar) else None


def entry_strictly_after(calendar: list[str], day: str) -> int | None:
    i = bisect.bisect_right(calendar, day)
    return i if i < len(calendar) else None


def close_on(series: dict, day: str) -> float | None:
    i = series["index"].get(day)
    if i is None:
        return None
    value = series["values"][i]
    return float(value) if value > 0 else None


def fill_windows(row: dict, series: dict, benches: dict, calendar: list[str]) -> None:
    stock_index = series["index"]
    for origin, day, finder in (
        ("member", row["d"], entry_on_or_after),
        ("follower", row["f"], entry_strictly_after),
    ):
        at = finder(calendar, day)
        if at is None:
            continue
        begin = calendar[at]
        start_px = close_on(series, begin)
        if start_px is None:
            continue
        for horizon in HORIZONS:
            end_at = at + horizon
            if end_at >= len(calendar):
                continue
            end = calendar[end_at]
            end_i = stock_index.get(end)
            if end_i is None:
                continue
            end_px = series["values"][end_i]
            if end_px <= 0:
                continue
            stock_ret = (end_px / start_px - 1.0) * 100.0
            row[f"{origin}_{horizon}_stock"] = stock_ret
            for bench_name in BENCHMARKS:
                bench = benches[bench_name]
                b_start = close_on(bench, begin)
                b_end = close_on(bench, end)
                if b_start is None or b_end is None:
                    continue
                bench_ret = (b_end / b_start - 1.0) * 100.0
                row[f"{origin}_{horizon}_{bench_name}"] = stock_ret - bench_ret

    member_at = entry_on_or_after(calendar, row["d"])
    follower_at = entry_strictly_after(calendar, row["f"])
    spy = benches["SPY"]
    if member_at is not None and follower_at is not None:
        begin = calendar[member_at]
        end = calendar[follower_at]
        s0 = close_on(series, begin)
        s1 = close_on(series, end)
        b0 = close_on(spy, begin)
        b1 = close_on(spy, end)
        if s0 is not None and s1 is not None and b0 is not None and b1 is not None:
            row["delay_SPY"] = 100.0 * (s1 / s0 - b1 / b0)


def source_r_errors(row: dict, series: dict, spy: dict, calendar: list[str]) -> dict | None:
    """Compare source trailing returns (through last close) with reconstructed entries."""
    src = row.get("r") or []
    if len(src) != 4 or any(v is None for v in src):
        return None
    last = calendar[-1]
    member_at = entry_on_or_after(calendar, row["d"])
    follower_at = entry_strictly_after(calendar, row["f"])
    if member_at is None or follower_at is None:
        return None
    mday, fday = calendar[member_at], calendar[follower_at]
    s_m = close_on(series, mday)
    s_f = close_on(series, fday)
    s_l = close_on(series, last)
    b_m = close_on(spy, mday)
    b_f = close_on(spy, fday)
    b_l = close_on(spy, last)
    if None in (s_m, s_f, s_l, b_m, b_f, b_l):
        return None
    return {
        "trade_stock_pp": 100.0 * (s_l / s_m - 1.0) - 100.0 * src[0],
        "trade_spy_pp": 100.0 * (b_l / b_m - 1.0) - 100.0 * src[1],
        "disc_stock_pp": 100.0 * (s_l / s_f - 1.0) - 100.0 * src[2],
        "disc_spy_pp": 100.0 * (b_l / b_f - 1.0) - 100.0 * src[3],
    }


def reconstruct() -> pd.DataFrame:
    DERIVED.mkdir(exist_ok=True)

    snapshot = json.loads((CACHE / "congress-trades.json").read_text())
    raw = snapshot["trades"] if isinstance(snapshot, dict) else snapshot
    candidates, sample_stats = candidate_trades(raw)

    tickers = {row["t"] for row in candidates} | set(BENCHMARKS)
    series = {}
    for ticker in tickers:
        path = CACHE / f"{ticker}.json"
        series[ticker] = load_series(path) if path.exists() else None

    spy = series.get("SPY")
    rsp = series.get("RSP")
    if not spy or spy["empty"] or not rsp or rsp["empty"]:
        raise RuntimeError("SPY and RSP adjusted closes are required in the cache")
    calendar = spy["dates"]
    if calendar != rsp["dates"]:
        missing_spy = set(calendar) - set(rsp["dates"])
        missing_rsp = set(rsp["dates"]) - set(calendar)
        raise RuntimeError(
            f"SPY/RSP calendars differ (spy-only {len(missing_spy)}, rsp-only {len(missing_rsp)})"
        )
    benches = {"SPY": spy, "RSP": rsp}

    counts = collections.Counter()
    excluded = []
    rows = []
    r_errors = []
    for idx, src in enumerate(candidates):
        stock = series.get(src["t"])
        reason = None
        if stock is None or stock["empty"]:
            reason = "no_price_history"
        elif stock["first"] and stock["first"] > src["d"]:
            reason = "later_listing"
        else:
            entry = entry_on_or_after(calendar, src["d"])
            if entry is None or calendar[entry] not in stock["index"]:
                reason = "no_entry_close"
        if reason:
            counts[reason] += 1
            excluded.append(
                {
                    "index": idx,
                    "ticker": src["t"],
                    "date": src["d"],
                    "filing": src["f"],
                    "reason": reason,
                    "yahoo_first": None if stock is None else stock.get("first"),
                }
            )
            continue
        delay_days = (
            dt.date.fromisoformat(src["f"]) - dt.date.fromisoformat(src["d"])
        ).days
        row = dict(
            src,
            index=idx,
            month=src["f"][:7],
            delay=delay_days,
            weight=(src["lo"] + src["hi"]) / 2.0,
        )
        fill_windows(row, stock, benches, calendar)
        err = source_r_errors(row, stock, spy, calendar)
        if err is not None:
            r_errors.append(err)
        rows.append(row)

    df = pd.DataFrame(rows)
    r_mae = {
        key: float(np.mean(np.abs([e[key] for e in r_errors]))) if r_errors else None
        for key in ("trade_stock_pp", "trade_spy_pp", "disc_stock_pp", "disc_spy_pp")
    }
    r_match = {
        "n_compared": len(r_errors),
        "mae_pp": r_mae,
        "frac_abs_lt_0_05_pp": {
            key: float(np.mean(np.abs([e[key] for e in r_errors]) < 0.05)) if r_errors else None
            for key in r_mae
        },
    }

    provenance = {
        **sample_stats,
        "retained_rows": int(len(df)),
        "members": int(df.m.nunique()) if len(df) else 0,
        "purchases": int((df.y == "P").sum()) if len(df) else 0,
        "sales": int((df.y == "S").sum()) if len(df) else 0,
        "exclusions": dict(counts),
        "source_exclusions": {"no_usable_price_history": 177, "later_listing": 70},
        "prices_through": calendar[-1],
        "source_r_check": r_match,
        "cache": str(CACHE),
    }
    (DERIVED / "exclusions.json").write_text(json.dumps(excluded, indent=2) + "\n")
    (DERIVED / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    df.to_pickle(DERIVED / "events.pkl")

    print(
        "sample",
        provenance["retained_rows"],
        "members",
        provenance["members"],
        "purchases",
        provenance["purchases"],
        "sales",
        provenance["sales"],
        "exclusions",
        provenance["exclusions"],
    )
    print("candidates", provenance["candidate_rows"], "from raw", provenance["raw_rows"])
    print("source r MAE pp", r_mae)
    for side in ("P", "S"):
        sub = df[df.y == side]
        cols = ["follower_126_RSP", "follower_126_SPY", "member_126_RSP", "delay_SPY"]
        print(
            side,
            [
                (
                    col,
                    int(sub[col].count()),
                    round(float(sub[col].median()), 4),
                    round(float(sub[col].mean()), 4),
                )
                for col in cols
                if col in sub
            ],
        )
    return df


if __name__ == "__main__":
    reconstruct()
