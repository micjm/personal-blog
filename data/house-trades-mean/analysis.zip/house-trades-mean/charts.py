"""Generate publication figures from the exported aggregate results."""
import pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.ticker import FuncFormatter
ROOT=pathlib.Path(__file__).resolve().parents[2]
PUBLIC=ROOT/'static/data/house-trades-mean'

OUT=ROOT/'static/images/house-trades-mean'
OUT.mkdir(parents=True,exist_ok=True)
s=pd.read_csv(PUBLIC/'all-results.csv')
BLUE='#1765a7';ORANGE='#c56b23';INK='#273440';GRAY='#8b959f';GRID='#e6e9ec'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.labelcolor':INK,'text.color':INK,'axes.edgecolor':GRID,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False,'xtick.color':'#64717e','ytick.color':INK,'figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'none','savefig.facecolor':'white'})

def save(fig,name):
 fig.savefig(OUT/(name+'.png'),dpi=180,bbox_inches='tight',pad_inches=.18)
 fig.savefig(OUT/(name+'.svg'),bbox_inches='tight',pad_inches=.18)
 plt.close(fig)
def clean(ax):
 ax.axvline(0,color='#9ba6ae',lw=1,zorder=0);ax.grid(axis='x',color=GRID,lw=.8);ax.set_axisbelow(True);ax.tick_params(axis='both',length=0)
 ax.xaxis.set_major_formatter(FuncFormatter(lambda x,pos:'0' if x==0 else f'{x:+g}'))
def pick(side='P',origin='follower',bench='RSP',days=126,group='All'):
 return s[(s.side==side)&(s.origin==origin)&(s.benchmark==bench)&(s.days==days)&(s.group==group)].iloc[0]
def err(ax,x,y,lo,hi,color):
 ax.plot([lo,hi],[y,y],color=color,lw=2,zorder=2)
 ax.scatter([x],[y],color=color,s=48,zorder=3)

fig,axs=plt.subplots(1,2,figsize=(9.2,3.8),sharey=True)
fig.suptitle('Changing the statistic changes the result',x=.02,ha='left',fontsize=17,fontweight='bold')
for ax,bench in zip(axs,['RSP','SPY']):
 clean(ax);ax.set_title('vs '+('equal-weight S&P 500 (RSP)' if bench=='RSP' else 'S&P 500 (SPY)'),loc='left',fontsize=11,pad=18)
 for y,side in [(1,'P'),(0,'S')]:
  r=pick(side=side,bench=bench);err(ax,r.mean_pp,y+.1,r.mean_ci90_low,r.mean_ci90_high,BLUE)
  ax.scatter(r.median_pp,y-.17,marker='D',s=35,color=GRAY)
  ax.text(r.mean_pp,y+.25,f'Mean {r.mean_pp:+.1f}',ha='center',fontsize=11,color=BLUE,fontweight='bold')
  ax.text(r.median_pp,y-.36,f'Median {r.median_pp:+.1f}',ha='center',fontsize=10,color='#66737e')
 ax.set_xlim(-5.7,7);ax.set_ylim(-.55,1.6);ax.set_xticks([-4,0,4]);ax.set_xlabel('Excess return (percentage points)')
axs[0].set_yticks([1,0],['Bought','Sold'])
fig.subplots_adjust(left=.10,right=.99,top=.79,bottom=.23,wspace=.17)
fig.text(.02,.02,'Six months after disclosure · 3,559 purchases / 3,980 sales\nLines: 90% intervals for means; sold = subsequent stock performance, not profit on a short.',fontsize=9,color='#64717e')
save(fig,'mean-vs-median')

fig,axs=plt.subplots(2,2,figsize=(9.2,6),sharex=True,sharey=True)
fig.suptitle('Mean returns at 1, 3 and 6 months',x=.02,ha='left',fontsize=17,fontweight='bold')
for row,origin in enumerate(['follower','member']):
 for col,bench in enumerate(['RSP','SPY']):
  ax=axs[row,col];ax.axhline(0,color='#9ba6ae',lw=1);ax.grid(axis='y',color=GRID);ax.tick_params(length=0)
  ax.set_title(('After disclosure' if origin=='follower' else 'From trade date')+' · '+bench,loc='left',fontsize=12)
  for side,color,label in [('P',BLUE,'Bought'),('S',ORANGE,'Sold')]:
   a=s[(s.side==side)&(s.group=='All')&(s.origin==origin)&(s.benchmark==bench)].sort_values('days')
   ax.plot([1,3,6],a.mean_pp,color=color,marker='o',lw=2,label=label)
   for x,r in zip([1,3,6],a.itertuples()):
    other=pick(side='S' if side=='P' else 'P',origin=origin,bench=bench,days=r.days).mean_pp
    above=r.mean_pp>=other
    label='0.0' if abs(r.mean_pp)<.05 else f'{r.mean_pp:+.1f}'
    ax.text(x,r.mean_pp+(.3 if above else -.6),label,ha='center',fontsize=10,color=color)
  ax.set_xticks([1,3,6],['1 month','3 months','6 months']);ax.set_ylim(-1.8,5.2)
  ax.yaxis.set_major_formatter(FuncFormatter(lambda x,p:'0' if x==0 else f'{x:+g}'))
  if col==0:ax.set_ylabel('Mean excess return (pp)')
axs[0,0].legend(frameon=False,loc='upper left',ncol=2,fontsize=9)
fig.subplots_adjust(left=.09,right=.98,top=.86,bottom=.15,hspace=.35,wspace=.12)
fig.text(.02,.025,'21 / 63 / 126 trading days · only completed windows enter each point.\nEqual weight per reported trade. Counts and interval estimates for every point are in the CSV.',fontsize=9,color='#64717e')
save(fig,'return-windows')

labels={'The member\'s own account':'Own account','Spouse, joint or child':'Spouse / joint / child','Disclosed within 30 days':'Disclosed ≤30 days','Disclosed after 30 days':'Disclosed >30 days','Disclosed after the 45-day deadline':'Disclosed >45 days','The 10 most active traders':'10 most active traders'}
for side,title,name in [('P','What members bought','purchase-groups'),('S','What members sold','sale-groups')]:
 a=s[(s.side==side)&(s.origin=='follower')&(s.days==126)&(s.benchmark=='RSP')].reset_index(drop=True)
 fig,ax=plt.subplots(figsize=(9.2,6.25));fig.suptitle(title,x=.02,ha='left',fontsize=17,fontweight='bold')
 fig.text(.02,.90,'Mean six-month excess return after disclosure, versus RSP',fontsize=11)
 clean(ax)
 for i,r in a.iterrows():
  y=len(a)-1-i
  if i%2==0:ax.axhspan(y-.45,y+.45,color='#f7f8fa',zorder=-1)
  err(ax,r.mean_pp,y,r.mean_ci90_low,r.mean_ci90_high,BLUE if side=='P' else ORANGE)
  ax.scatter(r.median_pp,y,s=27,marker='D',color=GRAY,zorder=3)
  ax.text(1.015,y,f'{r.mean_pp:+.1f}',transform=ax.get_yaxis_transform(),ha='right',va='center',fontsize=10,fontweight='bold')
  ax.text(1.15,y,f'{r.n:,}',transform=ax.get_yaxis_transform(),ha='right',va='center',fontsize=10,color='#64717e')
 ax.set_yticks(range(len(a)-1,-1,-1),[labels.get(g,g) for g in a.group]);ax.set_ylim(-.7,len(a)-.3)
 ax.set_xlim(-5,12.5);ax.set_xticks([-4,0,4,8,12]);ax.set_xlabel('Excess return (percentage points)')
 ax.text(1.015,1.015,'Mean',transform=ax.transAxes,ha='right',fontsize=9,color='#64717e')
 ax.text(1.15,1.015,'n',transform=ax.transAxes,ha='right',fontsize=9,color='#64717e')
 fig.subplots_adjust(left=.27,right=.87,top=.85,bottom=.16)
 fig.text(.02,.025,'● Mean with 90% month-bootstrap interval     ◆ Median\nGroups overlap. Intervals are pointwise; no adjustment for multiple subgroup comparisons.',fontsize=9,color='#64717e')
 save(fig,name)

fig,axs=plt.subplots(1,2,figsize=(9.2,4.6),sharey=True)
fig.suptitle('Bigger trades change the averages, too',x=.02,ha='left',fontsize=17,fontweight='bold')
for ax,bench in zip(axs,['RSP','SPY']):
 clean(ax);ax.set_title('vs '+bench,loc='left',pad=20)
 for y,(origin,side) in enumerate([('member','S'),('member','P'),('follower','S'),('follower','P')]):
  r=pick(side=side,origin=origin,bench=bench)
  err(ax,r.mean_pp,y+.13,r.mean_ci90_low,r.mean_ci90_high,GRAY)
  err(ax,r.midpoint_weighted_mean_pp,y-.13,r.weighted_ci90_low,r.weighted_ci90_high,BLUE)
  ax.text(r.midpoint_weighted_mean_pp,y-.42,f'{r.midpoint_weighted_mean_pp:+.1f}',color=BLUE,ha='center',fontsize=10,fontweight='bold')
 ax.set_xlim(-8,10);ax.set_xticks([-8,-4,0,4,8]);ax.set_ylim(-.7,3.8);ax.set_xlabel('Excess return (pp)')
axs[0].set_yticks([3,2,1,0],['Disclosure · bought','Disclosure · sold','Trade date · bought','Trade date · sold'])
fig.subplots_adjust(left=.22,right=.99,top=.79,bottom=.22,wspace=.12)
fig.text(.02,.025,'Blue: amount-midpoint weighted mean   Gray: equal-weight mean   Lines: 90% intervals\nSix-month windows. Reported dollar ranges only approximate actual trade sizes.',fontsize=9,color='#64717e')
save(fig,'amount-weighting')

t=pd.read_csv(PUBLIC/'tail-contributions.csv');t=t[np.isclose(t.top_fraction,.05)]
fig,ax=plt.subplots(figsize=(9.2,3.7));fig.suptitle('The top 5% carry the average',x=.02,ha='left',fontsize=17,fontweight='bold')
clean(ax)
for y,side in [(1,'P'),(0,'S')]:
 r=t[t.side==side].iloc[0]
 ax.barh(y,r.rest_contribution_pp,color='#aab3bc',height=.38);ax.barh(y,r.top_contribution_pp,color=BLUE,height=.38)
 ax.text(r.rest_contribution_pp/2,y,f'{r.rest_contribution_pp:+.1f}',ha='center',va='center',color='white',fontweight='bold')
 ax.text(r.top_contribution_pp/2,y,f'{r.top_contribution_pp:+.1f}',ha='center',va='center',color='white',fontweight='bold')
 ax.text(6.3,y,f'= {r.full_mean_pp:+.1f} pp',va='center',fontweight='bold')
ax.set_xlim(-4,8);ax.set_xticks([-4,-2,0,2,4,6]);ax.set_yticks([1,0],['Bought','Sold']);ax.set_xlabel('Contribution to the full-sample mean (pp)');ax.set_ylim(-.6,1.6)
fig.subplots_adjust(left=.10,right=.99,top=.80,bottom=.27)
fig.text(.02,.025,'Gray: remaining 95%   Blue: best 5% of excess returns\nSix months after disclosure, versus RSP. An accounting decomposition; no trades trimmed from the mean.',fontsize=9,color='#64717e')
save(fig,'tail-contributions')
print('Saved six chart pairs to',OUT)
