"""Validate the frozen House-trade price cache. Does not download or write.

The reconstruction must reuse the read-only snapshot at
/Users/michaelmayer/personal-blog/analysis/house-trades-mean/.cache/
(or $HOUSE_TRADES_CACHE). This script only checks that the snapshot and
Yahoo chart files are present. It will not fetch 1,259 tickers or mutate
that directory.
"""
from __future__ import annotations

import json
import sys

from analyze import CACHE, META_STEMS, candidate_trades, cache_dir


def main() -> int:
    cache = cache_dir()
    source = cache / "congress-trades.json"
    spy = cache / "SPY.json"
    rsp = cache / "RSP.json"
    if cache == CACHE:
        pass
    missing = [p.name for p in (source, spy, rsp) if not p.is_file()]
    if missing:
        print("Missing required cache files:", ", ".join(missing), file=sys.stderr)
        print("Refusing to download. Place the frozen snapshot in", cache, file=sys.stderr)
        return 1
    raw = json.loads(source.read_text())
    trades = raw["trades"] if isinstance(raw, dict) else raw
    candidates, stats = candidate_trades(trades)
    tickers = sorted({row["t"] for row in candidates} | {"SPY", "RSP"})
    present = 0
    absent = []
    for ticker in tickers:
        path = cache / f"{ticker}.json"
        if path.is_file():
            present += 1
        else:
            absent.append(ticker)
    extra = sorted(
        p.stem
        for p in cache.glob("*.json")
        if p.stem not in META_STEMS and p.stem not in set(tickers)
    )
    print("cache", cache)
    print("read_only", True)
    print("raw_rows", stats["raw_rows"], "candidates", stats["candidate_rows"])
    print("tickers_needed", len(tickers), "present", present, "absent", len(absent))
    if absent:
        print("absent_tickers", ",".join(absent[:40]), file=sys.stderr)
        return 1
    print("spy_rsp", spy.is_file() and rsp.is_file())
    print("extra_json_stems", len(extra))
    print("ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
