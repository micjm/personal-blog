# House-trades mean reconstruction audit

Independent reconstruction of Arkanum's House-trade event study
(https://arkanumdata.com/research/house-trades), replacing headline medians
with equal-weight arithmetic means. Original source code was not available.
The frozen Yahoo/Arkanum cache was used read-only.

## Inputs

- Snapshot: `/Users/michaelmayer/personal-blog/analysis/house-trades-mean/.cache/congress-trades.json` (9445 rows).
- Prices: Yahoo chart JSON in the same cache, adjusted closes through 2026-11-13.
- Cache was not mutated; derived files go to `analysis/house-trades-mean/.derived/`.
- No ticker re-download. Share-class punctuation maps only as `BRK.B` → file `BRK.B.json` (Yahoo symbol `BRK-B` already stored). No extra aliases (`SQ` is not mapped to `XYZ`).

## Sample construction

| Step | n |
| --- | --- |
| Raw snapshot rows | 9445 |
| Unclear transaction dates (`du`) dropped | 4 |
| Duplicate filing lines dropped (member, ticker, trade date, filing date, side, amount bounds, owner, source URL; last copy kept) | 253 |
| Candidates | 9188 |
| Retained | 8941 |
| Purchases / sales / members | 4142 / 4799 / 99 |

Paper sample: 8941 retained, 4142 buys, 4799 sales, 99 members, 9,188 candidates. Candidate delay on the 9,188: median 27 calendar days, 90th percentile 56, 11.7% after the 45-day deadline (paper: 27, 56, 12%).

Duplicates were identical filing lines (216 groups, 253 extra rows), not distinct same-day same-ticker trades. Rows that differ in owner, amount, date, or URL are kept.

## Exclusions (prices)

Reconstructed: 170 no usable Yahoo adj-close series, 67 with Yahoo `firstTradeDate` after the trade, 10 with history but no adj close on the member-entry session. Total dropped after candidates: 247.

Paper: 177 unavailable + 70 later listings = 247. Same total, different labels. Yahoo-only (paper also names Tiingo as a fallback). Empty Yahoo series with a *future* `firstTradeDate` are counted here as no price history, not later listings, because there are no bars to use. `no_entry_close` includes names whose first bar is after the trade even though `firstTradeDate` is not (WBD/EA/KVUE/PSKY/CRNX gaps around 2026 restructurings). Exclusions were not retuned to force 177/70.

Retention rule: keep a candidate if the first SPY session on or after the trade date has a positive adjusted close for that ticker. Follower windows are complete-case and can be missing without dropping the trade from group totals.

## Date alignment and return arithmetic

- Member entry: first SPY session **on or after** the transaction date.
- Follower entry: first SPY session **strictly after** the filing date.
- Exit: exactly 21, 63, or 126 SPY sessions later. Incomplete horizons are dropped, not filled.
- Stock and benchmark must both have a positive adj close on the exact entry and exit sessions.
- Excess = stock total return − benchmark total return, in percentage points, not a ratio of wealth relatives.
- SPY and RSP calendars in this cache are identical (510 sessions, 2024-11-01 through 2026-11-13).
- Yahoo timestamps converted as UTC calendar dates; US session opens (13:30/14:30 UTC) keep the New York date.

Source trailing field `r` (stock and S&P through last close, from trade then from disclosure) vs the same entries: n=8939. MAE: trade stock 0.038 pp, trade SPY 0.003 pp, disclosure stock 0.037 pp, disclosure SPY 0.003 pp. Share within 0.05 pp: stock 94.5% / 94.5%; SPY 100%. Strictly-after disclosure matches `r`; using the filing-date session as entry does not (MAE ~2 pp). SPY matches to rounding. Residual stock MAE is from Yahoo vs Arkanum's price vendor, not from a wrong clock.

## Grouping, denominators, bootstrap

13 appendix groups per side. Amount buckets use the reported upper bound. Top ten traders ranked by all retained purchases plus sales before any horizon filter: April McClain Delaney, Bruce Westerman, Gilbert Ray Cisneros, Jr., Jefferson Shreve, Josh Gottheimer, Julie Johnson, Lisa C. McClain, Marjorie Taylor Greene, Robert P. Bresnahan, Jr., Val T. Hoyle. Unknown party stays in All and other applicable groups.

Group **totals** vs paper: all 26 match. Effective follower six-month **n** vs paper: all 22 published cells match. Complete-case n is always ≤ the group total.

90% intervals: 400 draws of whole disclosure months with replacement, seed 20261115, 5th/95th percentiles of the equal-weight or amount-weighted mean. Follower six-month sample spans 17 disclosure months; member six-month spans 20. Buy-minus-sale resamples a shared month universe and subtracts within each replicate; months missing one side contribute nothing to that side. Intervals are pointwise.

Tail: `ceil(n * fraction)` best excess returns; subset sum / n. Top 5% and the rest add to the untrimmed mean.

## Headline means (not medians)

Follower, six months, purchases (n=3559): mean vs RSP +1.96 pp (90% -0.15 to +4.36); vs SPY -0.60 pp. Median vs RSP -2.38 pp; win rate 46.3%. Amount-midpoint weighted mean vs RSP +4.21 pp.

Sales are subsequent stock performance (n=3980): mean vs RSP +3.43 pp. A positive sale number is not a short profit.

Top 5% contribution to the purchase mean: +5.06 pp; remaining 95%: -3.09 pp.

Disclosure-window excess vs SPY (trade entry to follower entry): purchases mean -0.59 pp, median -0.65 pp (paper median −0.7%).

## Discrepancies vs published medians

Max |reconstructed − published| six-month median: 0.1437 pp. Cells off by more than 0.05 pp: 9 of 78. Published figures are rounded to 0.1 pp; remaining gaps are consistent with a different price snapshot (Yahoo vs Yahoo+Tiingo) and with even-n median interpolation. They were not fitted away.

This is not bit-for-bit replication of Arkanum's table, and it is not a claim that the original medians are wrong.

## What this is not

Event-window equal-weight (or range-midpoint-weighted) means are not realized portfolio returns. No costs, taxes, or risk adjustment. Survivorship: names without Yahoo history are out; that likely inflates means slightly. No inference of corruption from these numbers.
