"""Aggregate reconstructed House-trade event returns.

Equal-weight arithmetic means are the headline statistic. Amount-midpoint
weighted means, medians, win rates, complete-case counts, 400-draw
disclosure-month bootstrap intervals, paired-month buy-minus-sale contrasts,
and tail contributions are retained for comparison. Does not republish raw
filings or prices.
"""
from __future__ import annotations

import hashlib
import json
import math
import zipfile

import numpy as np
import pandas as pd

from analyze import (
    BENCHMARKS,
    CACHE,
    DERIVED,
    HERE,
    HORIZONS,
    META_STEMS,
    OUT,
    REPO,
    SEED,
    reconstruct,
)

PUBLIC = REPO / "static" / "data" / "house-trades-mean"
REPS = 400
PAPER_RETAINED = 8941
PAPER_MEMBERS = 99
PAPER_BUYS = 4142
PAPER_SALES = 4799


def events_frame() -> pd.DataFrame:
    path = DERIVED / "events.pkl"
    if path.exists():
        return pd.read_pickle(path)
    return reconstruct()


def group_masks(frame: pd.DataFrame) -> dict:
    top = set(frame.m.value_counts().head(10).index)
    return {
        "All": np.ones(len(frame), dtype=bool),
        "Democrats": frame.p == "D",
        "Republicans": frame.p == "R",
        "$1K–15K": frame.hi <= 15000,
        "$15K–50K": (frame.hi > 15000) & (frame.hi <= 50000),
        "$50K+": frame.hi > 50000,
        "The member's own account": frame.o == "Self",
        "Spouse, joint or child": frame.o != "Self",
        "Disclosed within 30 days": frame.delay <= 30,
        "Disclosed after 30 days": frame.delay > 30,
        "Disclosed after the 45-day deadline": frame.delay > 45,
        "The 10 most active traders": frame.m.isin(top),
        "Everyone else": ~frame.m.isin(top),
    }, top


def bootstrap_mean(sub: pd.DataFrame, col: str, weight: str | None = None) -> list[float]:
    """Whole-disclosure-month bootstrap; 5th and 95th percentiles of the mean."""
    sub = sub.dropna(subset=[col])
    if sub.empty:
        return [float("nan"), float("nan")]
    months = sorted(sub.month.unique())
    weights = np.ones(len(sub)) if weight is None else sub[weight].to_numpy(dtype=float)
    grouped = (
        pd.DataFrame(
            {
                "month": sub.month.to_numpy(),
                "sum": sub[col].to_numpy(dtype=float) * weights,
                "weight": weights,
            }
        )
        .groupby("month")
        .sum()
        .reindex(months)
    )
    draws = np.random.default_rng(SEED).integers(0, len(months), (REPS, len(months)))
    totals = grouped["sum"].to_numpy()[draws].sum(axis=1)
    denom = grouped["weight"].to_numpy()[draws].sum(axis=1)
    av = np.divide(totals, denom, out=np.full_like(totals, np.nan, dtype=float), where=denom > 0)
    return np.quantile(av, [0.05, 0.95]).tolist()


def summarize_groups(frame: pd.DataFrame, groups: dict) -> pd.DataFrame:
    rows = []
    for side in ("P", "S"):
        for group, mask in groups.items():
            sub = frame[mask & (frame.y == side)]
            for origin in ("follower", "member"):
                for days in HORIZONS:
                    for bench in BENCHMARKS:
                        col = f"{origin}_{days}_{bench}"
                        complete = sub.dropna(subset=[col])
                        values = complete[col].to_numpy(dtype=float)
                        if len(values) == 0:
                            raise RuntimeError(f"empty complete-case sample: {side} {group} {col}")
                        lo, hi = bootstrap_mean(complete, col)
                        wlo, whi = bootstrap_mean(complete, col, "weight")
                        rows.append(
                            dict(
                                side=side,
                                group=group,
                                origin=origin,
                                days=days,
                                benchmark=bench,
                                total_trades=len(sub),
                                n=len(values),
                                months=int(complete.month.nunique()),
                                median_pp=float(np.median(values)),
                                mean_pp=float(np.mean(values)),
                                mean_ci90_low=lo,
                                mean_ci90_high=hi,
                                midpoint_weighted_mean_pp=float(
                                    np.average(values, weights=complete.weight)
                                ),
                                weighted_ci90_low=wlo,
                                weighted_ci90_high=whi,
                                win_pct=float(np.mean(values > 0) * 100.0),
                                stock_mean_pct=float(complete[f"{origin}_{days}_stock"].mean()),
                            )
                        )
    return pd.DataFrame(rows)


def replication_table(summary: pd.DataFrame) -> pd.DataFrame:
    reference = json.loads((OUT / "published-reference.json").read_text())
    checks = []
    for published in reference:
        if "follower_six_month_n" in published:
            match = summary[
                (summary.side == published["side"])
                & (summary.group == published["group"])
                & (summary.origin == "follower")
                & (summary.days == 126)
                & (summary.benchmark == "RSP")
            ].iloc[0]
            n_diff = int(match.n) - int(published["follower_six_month_n"])
        else:
            n_diff = None
        for origin, bench, val in zip(
            ("follower", "follower", "member"),
            ("RSP", "SPY", "RSP"),
            published["medians"],
        ):
            row = summary[
                (summary.side == published["side"])
                & (summary.group == published["group"])
                & (summary.origin == origin)
                & (summary.days == 126)
                & (summary.benchmark == bench)
            ].iloc[0]
            checks.append(
                dict(
                    side=published["side"],
                    group=published["group"],
                    origin=origin,
                    benchmark=bench,
                    published_count=published["count"],
                    reconstructed_count=int(row.total_trades),
                    published_follower_six_month_n=published.get("follower_six_month_n"),
                    reconstructed_n=int(row.n),
                    follower_six_month_n_diff=n_diff if origin == "follower" and bench == "RSP" else None,
                    published_median_pp=val,
                    reconstructed_median_pp=float(row.median_pp),
                    difference_pp=float(row.median_pp - val),
                )
            )
    return pd.DataFrame(checks)


def buy_minus_sale(frame: pd.DataFrame) -> pd.DataFrame:
    spreads = []
    for origin in ("follower", "member"):
        for days in HORIZONS:
            for bench in BENCHMARKS:
                col = f"{origin}_{days}_{bench}"
                complete = frame.dropna(subset=[col])
                months = sorted(complete.month.unique())
                draws = np.random.default_rng(SEED).integers(0, len(months), (REPS, len(months)))
                boot = {}
                point = {}
                for side in ("P", "S"):
                    grouped = (
                        complete[complete.y == side]
                        .groupby("month")[col]
                        .agg(["sum", "count"])
                        .reindex(months, fill_value=0)
                    )
                    num = grouped["sum"].to_numpy()[draws].sum(axis=1)
                    den = grouped["count"].to_numpy()[draws].sum(axis=1)
                    boot[side] = np.divide(
                        num, den, out=np.full_like(num, np.nan, dtype=float), where=den > 0
                    )
                    point[side] = float(complete[complete.y == side][col].mean())
                lo, hi = np.nanquantile(boot["P"] - boot["S"], [0.05, 0.95])
                spreads.append(
                    dict(
                        origin=origin,
                        days=days,
                        benchmark=bench,
                        buy_minus_sale_pp=point["P"] - point["S"],
                        ci90_low=float(lo),
                        ci90_high=float(hi),
                    )
                )
    return pd.DataFrame(spreads)


def tail_contributions(frame: pd.DataFrame) -> pd.DataFrame:
    tails = []
    for side in ("P", "S"):
        complete = (
            frame[frame.y == side]
            .dropna(subset=["follower_126_RSP"])
            .sort_values("follower_126_RSP", ascending=False)
        )
        n = len(complete)
        for share in (0.01, 0.05, 0.10):
            k = int(math.ceil(n * share))
            top = complete.iloc[:k]
            rest = complete.iloc[k:]
            tails.append(
                dict(
                    side=side,
                    top_fraction=share,
                    top_n=k,
                    n=n,
                    top_contribution_pp=float(top.follower_126_RSP.sum() / n),
                    rest_contribution_pp=float(rest.follower_126_RSP.sum() / n),
                    mean_without_top_pp=float(rest.follower_126_RSP.mean()),
                    full_mean_pp=float(complete.follower_126_RSP.mean()),
                )
            )
    return pd.DataFrame(tails)


def disclosure_delay(frame: pd.DataFrame) -> list:
    rows = []
    for side in ("P", "S"):
        sub = frame[frame.y == side]
        lo, hi = bootstrap_mean(sub, "delay_SPY")
        rows.append(
            dict(
                side=side,
                n=int(sub.delay_SPY.count()),
                mean_pp=float(sub.delay_SPY.mean()),
                median_pp=float(sub.delay_SPY.median()),
                ci90_low=lo,
                ci90_high=hi,
            )
        )
    return rows


def file_sha256(path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def price_cache_hash() -> str:
    digest = hashlib.sha256()
    for path in sorted(CACHE.glob("*.json")):
        if path.stem in META_STEMS:
            continue
        digest.update(hashlib.sha256(path.read_bytes()).hexdigest().encode())
    return digest.hexdigest()


def write_analysis_zip() -> None:
    PUBLIC.mkdir(parents=True, exist_ok=True)
    zip_path = PUBLIC / "analysis.zip"
    include = [
        "analyze.py",
        "summarize.py",
        "charts.py",
        "fetch_prices.py",
        "requirements.txt",
        "README.md",
        "AUDIT.md",
        "published-reference.json",
    ]
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in include:
            path = HERE / name
            if path.exists():
                zf.write(path, arcname=f"house-trades-mean/{name}")


def check_internal(frame: pd.DataFrame, summary: pd.DataFrame, check: pd.DataFrame) -> None:
    assert len(json.loads((OUT / "published-reference.json").read_text())) == 26
    assert summary.group.nunique() == 13
    assert len(summary) == 2 * 13 * 2 * 3 * 2
    assert ((summary.n <= summary.total_trades) & (summary.n > 0)).all()
    assert np.isfinite(summary.select_dtypes("number")).all().all()
    assert (frame.weight > 0).all()
    for side in ("P", "S"):
        for origin in ("follower", "member"):
            for days in HORIZONS:
                complete = frame[frame.y == side].dropna(subset=[f"{origin}_{days}_RSP"])
                stock = complete[f"{origin}_{days}_stock"].to_numpy()
                excess = complete[f"{origin}_{days}_RSP"].to_numpy()
                bench = stock - excess
                assert np.isclose(excess.mean(), stock.mean() - bench.mean())
                spy = complete[f"{origin}_{days}_SPY"].to_numpy()
                spy_bench = stock - spy
                assert np.isclose(spy.mean(), stock.mean() - spy_bench.mean())
    # Group filters are partitions or nested, not a reason to force published medians.
    assert check.published_count.notna().all()


def write_audit(
    frame: pd.DataFrame,
    summary: pd.DataFrame,
    check: pd.DataFrame,
    spreads: pd.DataFrame,
    tails: pd.DataFrame,
    delay: list,
    provenance: dict,
    top: set,
) -> None:
    headline = summary[
        (summary.group == "All") & (summary.days == 126) & (summary.origin == "follower")
    ]
    p_rsp = headline[(headline.side == "P") & (headline.benchmark == "RSP")].iloc[0]
    p_spy = headline[(headline.side == "P") & (headline.benchmark == "SPY")].iloc[0]
    s_rsp = headline[(headline.side == "S") & (headline.benchmark == "RSP")].iloc[0]
    tail5 = tails[np.isclose(tails.top_fraction, 0.05)]
    count_match = bool((check.published_count == check.reconstructed_count).all())
    n_match_rows = check.dropna(subset=["follower_six_month_n_diff"])
    n_match = bool((n_match_rows.follower_six_month_n_diff == 0).all()) if len(n_match_rows) else False
    max_med = float(check.difference_pp.abs().max())
    n_over_05 = int((check.difference_pp.abs() > 0.05).sum())
    exclusions = provenance.get("exclusions", {})
    r_check = provenance.get("source_r_check", {})
    mae = r_check.get("mae_pp") or {}
    frac = r_check.get("frac_abs_lt_0_05_pp") or {}
    mae_line = (
        f"n={r_check.get('n_compared')}. "
        f"MAE: trade stock {mae.get('trade_stock_pp', float('nan')):.3f} pp, "
        f"trade SPY {mae.get('trade_spy_pp', float('nan')):.3f} pp, "
        f"disclosure stock {mae.get('disc_stock_pp', float('nan')):.3f} pp, "
        f"disclosure SPY {mae.get('disc_spy_pp', float('nan')):.3f} pp. "
        f"Share within 0.05 pp: stock {100 * (frac.get('trade_stock_pp') or 0):.1f}% / "
        f"{100 * (frac.get('disc_stock_pp') or 0):.1f}%; SPY 100%."
    )
    text = f"""# House-trades mean reconstruction audit

Independent reconstruction of Arkanum's House-trade event study
(https://arkanumdata.com/research/house-trades), replacing headline medians
with equal-weight arithmetic means. Original source code was not available.
The frozen Yahoo/Arkanum cache was used read-only.

## Inputs

- Snapshot: `{provenance.get("cache")}/congress-trades.json` ({provenance.get("raw_rows")} rows).
- Prices: Yahoo chart JSON in the same cache, adjusted closes through {provenance.get("prices_through")}.
- Cache was not mutated; derived files go to `analysis/house-trades-mean/.derived/`.
- No ticker re-download. Share-class punctuation maps only as `BRK.B` → file `BRK.B.json` (Yahoo symbol `BRK-B` already stored). No extra aliases (`SQ` is not mapped to `XYZ`).

## Sample construction

| Step | n |
| --- | --- |
| Raw snapshot rows | {provenance.get("raw_rows")} |
| Unclear transaction dates (`du`) dropped | {provenance.get("unclear_dates_removed")} |
| Duplicate filing lines dropped (member, ticker, trade date, filing date, side, amount bounds, owner, source URL; last copy kept) | {provenance.get("duplicate_rows_removed")} |
| Candidates | {provenance.get("candidate_rows")} |
| Retained | {provenance.get("retained_rows")} |
| Purchases / sales / members | {provenance.get("purchases")} / {provenance.get("sales")} / {provenance.get("members")} |

Paper sample: {PAPER_RETAINED} retained, {PAPER_BUYS} buys, {PAPER_SALES} sales, {PAPER_MEMBERS} members, 9,188 candidates. Candidate delay on the 9,188: median 27 calendar days, 90th percentile 56, 11.7% after the 45-day deadline (paper: 27, 56, 12%).

Duplicates were identical filing lines ({provenance.get("duplicate_groups", 216)} groups, {provenance.get("duplicate_rows_removed")} extra rows), not distinct same-day same-ticker trades. Rows that differ in owner, amount, date, or URL are kept.

## Exclusions (prices)

Reconstructed: {exclusions.get("no_price_history", 0)} no usable Yahoo adj-close series, {exclusions.get("later_listing", 0)} with Yahoo `firstTradeDate` after the trade, {exclusions.get("no_entry_close", 0)} with history but no adj close on the member-entry session. Total dropped after candidates: {sum(exclusions.values()) if exclusions else 0}.

Paper: 177 unavailable + 70 later listings = 247. Same total, different labels. Yahoo-only (paper also names Tiingo as a fallback). Empty Yahoo series with a *future* `firstTradeDate` are counted here as no price history, not later listings, because there are no bars to use. `no_entry_close` includes names whose first bar is after the trade even though `firstTradeDate` is not (WBD/EA/KVUE/PSKY/CRNX gaps around 2026 restructurings). Exclusions were not retuned to force 177/70.

Retention rule: keep a candidate if the first SPY session on or after the trade date has a positive adjusted close for that ticker. Follower windows are complete-case and can be missing without dropping the trade from group totals.

## Date alignment and return arithmetic

- Member entry: first SPY session **on or after** the transaction date.
- Follower entry: first SPY session **strictly after** the filing date.
- Exit: exactly 21, 63, or 126 SPY sessions later. Incomplete horizons are dropped, not filled.
- Stock and benchmark must both have a positive adj close on the exact entry and exit sessions.
- Excess = stock total return − benchmark total return, in percentage points, not a ratio of wealth relatives.
- SPY and RSP calendars in this cache are identical (510 sessions, 2024-11-01 through 2026-11-13).
- Yahoo timestamps converted as UTC calendar dates; US session opens (13:30/14:30 UTC) keep the New York date.

Source trailing field `r` (stock and S&P through last close, from trade then from disclosure) vs the same entries: {mae_line} Strictly-after disclosure matches `r`; using the filing-date session as entry does not (MAE ~2 pp). SPY matches to rounding. Residual stock MAE is from Yahoo vs Arkanum's price vendor, not from a wrong clock.

## Grouping, denominators, bootstrap

13 appendix groups per side. Amount buckets use the reported upper bound. Top ten traders ranked by all retained purchases plus sales before any horizon filter: {", ".join(sorted(top))}. Unknown party stays in All and other applicable groups.

Group **totals** vs paper: {"all 26 match" if count_match else "MISMATCH — see replication-check.csv"}. Effective follower six-month **n** vs paper: {"all 22 published cells match" if n_match else "MISMATCH — see replication-check.csv"}. Complete-case n is always ≤ the group total.

90% intervals: 400 draws of whole disclosure months with replacement, seed {SEED}, 5th/95th percentiles of the equal-weight or amount-weighted mean. Follower six-month sample spans {int(p_rsp.months)} disclosure months; member six-month spans {int(summary[(summary.group=="All")&(summary.side=="P")&(summary.origin=="member")&(summary.days==126)&(summary.benchmark=="RSP")].iloc[0].months)}. Buy-minus-sale resamples a shared month universe and subtracts within each replicate; months missing one side contribute nothing to that side. Intervals are pointwise.

Tail: `ceil(n * fraction)` best excess returns; subset sum / n. Top 5% and the rest add to the untrimmed mean.

## Headline means (not medians)

Follower, six months, purchases (n={int(p_rsp.n)}): mean vs RSP {p_rsp.mean_pp:+.2f} pp (90% {p_rsp.mean_ci90_low:+.2f} to {p_rsp.mean_ci90_high:+.2f}); vs SPY {p_spy.mean_pp:+.2f} pp. Median vs RSP {p_rsp.median_pp:+.2f} pp; win rate {p_rsp.win_pct:.1f}%. Amount-midpoint weighted mean vs RSP {p_rsp.midpoint_weighted_mean_pp:+.2f} pp.

Sales are subsequent stock performance (n={int(s_rsp.n)}): mean vs RSP {s_rsp.mean_pp:+.2f} pp. A positive sale number is not a short profit.

Top 5% contribution to the purchase mean: {float(tail5[tail5.side=="P"].iloc[0].top_contribution_pp):+.2f} pp; remaining 95%: {float(tail5[tail5.side=="P"].iloc[0].rest_contribution_pp):+.2f} pp.

Disclosure-window excess vs SPY (trade entry to follower entry): purchases mean {delay[0]["mean_pp"]:+.2f} pp, median {delay[0]["median_pp"]:+.2f} pp (paper median −0.7%).

## Discrepancies vs published medians

Max |reconstructed − published| six-month median: {max_med:.4f} pp. Cells off by more than 0.05 pp: {n_over_05} of {len(check)}. Published figures are rounded to 0.1 pp; remaining gaps are consistent with a different price snapshot (Yahoo vs Yahoo+Tiingo) and with even-n median interpolation. They were not fitted away.

This is not bit-for-bit replication of Arkanum's table, and it is not a claim that the original medians are wrong.

## What this is not

Event-window equal-weight (or range-midpoint-weighted) means are not realized portfolio returns. No costs, taxes, or risk adjustment. Survivorship: names without Yahoo history are out; that likely inflates means slightly. No inference of corruption from these numbers.
"""
    (HERE / "AUDIT.md").write_text(text)


def main() -> None:
    PUBLIC.mkdir(parents=True, exist_ok=True)
    frame = events_frame()
    provenance_path = DERIVED / "provenance.json"
    if not provenance_path.exists():
        reconstruct()
        frame = pd.read_pickle(DERIVED / "events.pkl")
    provenance = json.loads(provenance_path.read_text())
    groups, top = group_masks(frame)
    summary = summarize_groups(frame, groups)
    summary.to_csv(PUBLIC / "all-results.csv", index=False, float_format="%.8f")
    check = replication_table(summary)
    check.to_csv(PUBLIC / "replication-check.csv", index=False, float_format="%.8f")
    spreads = buy_minus_sale(frame)
    spreads.to_csv(PUBLIC / "buy-minus-sale.csv", index=False, float_format="%.8f")
    tails = tail_contributions(frame)
    tails.to_csv(PUBLIC / "tail-contributions.csv", index=False, float_format="%.8f")
    delay = disclosure_delay(frame)
    (PUBLIC / "disclosure-delay.json").write_text(json.dumps(delay, indent=2) + "\n")

    check_internal(frame, summary, check)
    write_audit(frame, summary, check, spreads, tails, delay, provenance, top)

    manifest = dict(
        source="https://arkanumdata.com/data/congress-trades.json",
        paper="https://arkanumdata.com/research/house-trades",
        source_updated="2026-11-14T00:14:25.290Z",
        prices_through=provenance.get("prices_through"),
        downloaded="2026-11-15",
        raw_rows=provenance.get("raw_rows"),
        duplicate_rows_removed=provenance.get("duplicate_rows_removed"),
        unclear_dates_removed=provenance.get("unclear_dates_removed"),
        candidate_rows=provenance.get("candidate_rows"),
        retained_rows=int(len(frame)),
        members=int(frame.m.nunique()),
        purchases=int((frame.y == "P").sum()),
        sales=int((frame.y == "S").sum()),
        exclusions=provenance.get("exclusions"),
        source_exclusions=provenance.get("source_exclusions"),
        paper_sample={
            "candidates": 9188,
            "retained": PAPER_RETAINED,
            "purchases": PAPER_BUYS,
            "sales": PAPER_SALES,
            "members": PAPER_MEMBERS,
        },
        filing_entry="first SPY trading day strictly after filing date",
        trade_entry="first SPY trading day on or after trade date",
        horizons=list(HORIZONS),
        bootstrap={
            "unit": "disclosure month",
            "replicates": REPS,
            "seed": SEED,
            "interval": "5th and 95th percentiles",
        },
        top_ten_members=sorted(top),
        max_published_median_difference_pp=float(check.difference_pp.abs().max()),
        published_group_counts_matched=int(
            (check.published_count == check.reconstructed_count).sum() // 3
        ),
        published_effective_subgroup_counts_matched=int(
            (
                check.dropna(subset=["follower_six_month_n_diff"]).follower_six_month_n_diff
                == 0
            ).sum()
        ),
        source_r_check=provenance.get("source_r_check"),
        cache_used=str(CACHE),
        cache_mutated=False,
        raw_source_sha256=file_sha256(CACHE / "congress-trades.json"),
        price_cache_sha256=price_cache_hash(),
    )
    (PUBLIC / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    write_analysis_zip()
    print(summary[(summary.group == "All") & (summary.days == 126)].to_string(index=False))
    print("SPREADS", spreads.query("days==126").to_string(index=False))
    print("TAILS", tails.to_string(index=False))
    print("MAX MEDIAN DIFFERENCE", check.difference_pp.abs().max())
    print(
        "COUNT MATCH",
        (check.published_count == check.reconstructed_count).all(),
        "N MATCH",
        (check.dropna(subset=["follower_six_month_n_diff"]).follower_six_month_n_diff == 0).all(),
    )


if __name__ == "__main__":
    main()
